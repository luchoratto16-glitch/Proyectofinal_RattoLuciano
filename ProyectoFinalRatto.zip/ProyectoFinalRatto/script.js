// Proyecto Final — E-commerce Bolsas & Papelera
// Autor: Luciano Valentín Ratto

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const state = {
  productos: [],
  carrito: JSON.parse(localStorage.getItem('carrito')) || [],
  filtros: {
    inStock: true,
    promo: false,
    q: '',
    cat: ''
  },
  iva: 0.21,
  envio: 1200,
  descuento: 0
};

// ---------- UTILIDADES ---------- //
const money = (n) => n.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' });

function guardarCarrito() {
  localStorage.setItem('carrito', JSON.stringify(state.carrito));
  actualizarBadge();
}

function actualizarBadge() {
  const cantidad = state.carrito.reduce((acc, it) => acc + it.cantidad, 0);
  $('#badge').textContent = cantidad;
}

// ---------- CARGA DE PRODUCTOS ---------- //
async function cargarProductos() {
  const res = await fetch('data/products.json');
  const data = await res.json();
  state.productos = data;
  renderProductos();
  actualizarBadge();
}

// ---------- RENDER DE PRODUCTOS ---------- //
function renderProductos() {
  const cont = $('#cards');
  cont.innerHTML = '';
  const tpl = $('#tplCard');

  const filtrados = state.productos.filter(p => {
    if (state.filtros.inStock && p.stock <= 0) return false;
    if (state.filtros.promo && !p.promo) return false;
    if (state.filtros.cat && p.categoria !== state.filtros.cat) return false;
    if (state.filtros.q && !p.nombre.toLowerCase().includes(state.filtros.q)) return false;
    return true;
  });

  if (!filtrados.length) {
    cont.innerHTML = '<p class="muted">No se encontraron productos con los filtros actuales.</p>';
    return;
  }

  filtrados.forEach(p => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.img').src = p.img;
    node.querySelector('.img').alt = p.nombre;
    node.querySelector('.title').textContent = p.nombre;
    node.querySelector('.categoria').textContent = `Categoría: ${p.categoria}`;
    node.querySelector('.price').textContent = money(p.precio);
    node.querySelector('.stock').textContent = `Stock: ${p.stock} unidades`;
    node.querySelector('.agregar').addEventListener('click', () => agregarAlCarrito(p.id));
    node.querySelector('.ver').addEventListener('click', () => verDetalle(p));
    cont.appendChild(node);
  });
}

function verDetalle(p) {
  Swal.fire({
    title: p.nombre,
    html: `
      <p><b>Precio:</b> ${money(p.precio)}</p>
      <p><b>Categoría:</b> ${p.categoria}</p>
      <p><b>Stock:</b> ${p.stock}</p>
    `,
    imageUrl: p.img,
    imageAlt: p.nombre,
    confirmButtonText: 'Agregar al carrito',
    showCancelButton: true,
    cancelButtonText: 'Cerrar'
  }).then(res => {
    if (res.isConfirmed) agregarAlCarrito(p.id);
  });
}

// ---------- CARRITO ---------- //
function agregarAlCarrito(id) {
  const prod = state.productos.find(p => p.id === id);
  if (!prod || prod.stock <= 0) {
    Swal.fire('Sin stock', 'No hay unidades disponibles', 'warning');
    return;
  }
  const item = state.carrito.find(it => it.id === id);
  if (item) {
    if (item.cantidad + 1 > prod.stock) {
      Swal.fire('Límite de stock', 'No puedes agregar más de lo disponible', 'info');
      return;
    }
    item.cantidad++;
  } else {
    state.carrito.push({ id: prod.id, nombre: prod.nombre, precio: prod.precio, cantidad: 1 });
  }
  guardarCarrito();
  Swal.fire({ title: 'Agregado', text: `${prod.nombre}`, icon: 'success', timer: 800, showConfirmButton: false });
}

function abrirCarrito() {
  renderCarrito();
  const modal = $('#dlgCarrito');
  const overlay = $('#carritoOverlay');
  modal.classList.add('show');
  overlay.classList.add('show');
}

function cerrarCarrito() {
  const modal = $('#dlgCarrito');
  const overlay = $('#carritoOverlay');
  modal.classList.remove('show');
  overlay.classList.remove('show');
}


function renderCarrito() {
  const wrap = $('#carritoItems');
  wrap.innerHTML = '';
  state.carrito.forEach(it => {
    const prod = state.productos.find(p => p.id === it.id);
    const div = document.createElement('div');
    div.className = 'item';
    div.innerHTML = `
      <span>${it.nombre}</span>
      <span class="badge">${money(it.precio)}</span>
      <div class="qty">
        <button data-acc="-">-</button>
        <span>${it.cantidad}</span>
        <button data-acc="+">+</button>
      </div>
      <strong>${money(it.precio * it.cantidad)}</strong>
      <button class="icon" title="Quitar">&times;</button>
    `;
    const botones = div.querySelectorAll('.qty button');
    if (botones.length === 2) {
      const [btnMenos, btnMas] = botones;
      btnMenos.addEventListener('click', () => cambiarCantidad(it.id, -1));
      btnMas.addEventListener('click', () => cambiarCantidad(it.id, +1));
    }
    const btnQuitar = div.querySelector('.icon');
    if (btnQuitar) btnQuitar.addEventListener('click', () => quitarDelCarrito(it.id));
    wrap.appendChild(div);
  });
  calcularTotales();
}

function cambiarCantidad(id, delta) {
  const it = state.carrito.find(x => x.id === id);
  const prod = state.productos.find(p => p.id === id);
  if (!it || !prod) return;
  if (delta > 0 && it.cantidad + 1 > prod.stock) {
    Swal.fire('Límite de stock', 'No hay más unidades disponibles', 'info');
    return;
  }
  it.cantidad += delta;
  if (it.cantidad <= 0) state.carrito = state.carrito.filter(x => x.id !== id);
  guardarCarrito();
  renderCarrito();
  calcularTotales();
}

function quitarDelCarrito(id) {
  state.carrito = state.carrito.filter(x => x.id !== id);
  guardarCarrito();
  renderCarrito();
  calcularTotales();
}

function vaciarCarrito() {
  state.carrito = [];
  guardarCarrito();
  renderCarrito();
  calcularTotales();
}

function calcularTotales() {
  const sub = state.carrito.reduce((acc, it) => acc + it.precio * it.cantidad, 0);
  const iva = sub * state.iva;
  const total = sub + iva + (sub ? state.envio : 0);

  $('#totales').innerHTML = `
    <div>Subtotal: <b>${money(sub)}</b></div>
    <div>IVA (21%): <b>${money(iva)}</b></div>
    <div>Envío: <b>${money(sub ? state.envio : 0)}</b></div>
    <div>Total: <b>${money(total)}</b></div>
  `;

  if (state.descuento > 0 && state.carrito.length > 0) {
    const descMonto = total * (state.descuento / 100);
    const totalConDescuento = total - descMonto;
    $('#totalesDescuento').innerHTML = `
      <p>Subtotal: <b>${money(sub)}</b></p>
      <p>IVA (21%): <b>${money(iva)}</b></p>
      <p>Descuento (${state.descuento}%): <b>-${money(descMonto)}</b></p>
      <p><b>Total con descuento:</b> <b>${money(totalConDescuento)}</b></p>
    `;
    $('#totalesDescuento').style.display = 'block';
  } else {
    
    $('#totalesDescuento').innerHTML = '';
    $('#totalesDescuento').style.display = 'none';
  }

  return { sub, iva, total };
}
//------- Finalizar Compra ---------- //
async function finalizarCompra() {
  if (!state.carrito.length) {
    Swal.fire('Carrito vacío', 'Agregá productos antes de comprar', 'info');
    return;
  }


const nombreGuardado = localStorage.getItem('clienteNombre') || 'Luciano Valentín Ratto';
const emailGuardado = localStorage.getItem('clienteEmail') || 'luciano.ratto@example.com';
const provGuardada = localStorage.getItem('clienteProvincia') || 'Buenos Aires';

  
  const { value: datos } = await Swal.fire({
    title: 'Ingresá tus datos',
    html: `
      <input id="swalNombre" class="swal2-input" placeholder="Nombre completo" value="${nombreGuardado}">
      <input id="swalEmail" type="email" class="swal2-input" placeholder="Correo electrónico" value="${emailGuardado}">
      <input id="swalProv" class="swal2-input" placeholder="Provincia" value="${provGuardada}">
    `,
    confirmButtonText: 'Continuar',
    showCancelButton: true,
    cancelButtonText: 'Cancelar',
    preConfirm: () => {
      const nombre = document.getElementById('swalNombre').value.trim();
      const email = document.getElementById('swalEmail').value.trim();
      const provincia = document.getElementById('swalProv').value.trim();

      if (!nombre || !email || !provincia) {
        Swal.showValidationMessage('Completá todos los campos antes de continuar.');
        return false;
      }

      
      localStorage.setItem('clienteNombre', nombre);
      localStorage.setItem('clienteEmail', email);
      localStorage.setItem('clienteProvincia', provincia);

      return { nombre, email, provincia };
    }
  });

  if (!datos) return;

  const { total } = calcularTotales();
  const { nombre, email, provincia } = datos;

  
  Swal.fire({
    title: 'Confirmar compra',
    html: `
      <p><b>Cliente:</b> ${nombre} (${email})</p>
      <p><b>Provincia:</b> ${provincia}</p>
      <p><b>Total:</b> ${money(total)}</p>
    `,
    showCancelButton: true,
    confirmButtonText: 'Ir a pagar',
    cancelButtonText: 'Cancelar'
  }).then(res => {
    if (!res.isConfirmed) return;

  
    state.carrito.forEach(it => {
      const p = state.productos.find(x => x.id === it.id);
      if (p) p.stock -= it.cantidad;
    });

    const pedido = {
      id: Date.now(),
      items: state.carrito,
      total,
      cliente: { nombre, email, provincia },
      fecha: new Date().toISOString()
    };

    const historial = JSON.parse(localStorage.getItem('historial')) || [];
    historial.push(pedido);
    localStorage.setItem('historial', JSON.stringify(historial));

    
    state.carrito = [];
    guardarCarrito();
    renderCarrito();
    renderProductos();

  
    state.descuento = 0;
    $('#codigoDescuento').value = '';
    $('#ctzResultado').innerHTML = `
      <div class="box">
        <p><b>Subtotal:</b> $0,00</p>
        <p><b>IVA (21%):</b> $0,00</p>
        <p><b>Descuento:</b> $0,00</p>
        <p><b>Total con descuento:</b> $0,00</p>
      </div>
    `;
    $('#totalesDescuento').innerHTML = '';
    $('#totalesDescuento').style.display = 'none';

    cerrarCarrito();

    
    Swal.fire({
      title: 'Compra realizada',
      html: `
        <p>Enviamos un mail a <b>${email}</b> con el código de pago.</p>
        <p>Gracias por tu compra.</p>
      `,
      icon: 'success',
      confirmButtonText: 'Aceptar'
    });
  });
}

// ---------- VALIDACIÓN DE CÓDIGOS ---------- //
$('#frmCodigo').addEventListener('submit', async (e) => {
  e.preventDefault();
  const codigo = $('#codigoDescuento').value.trim().toUpperCase();
  if (!codigo) return Swal.fire('Error', 'Ingresá un código válido.', 'warning');

  try {
    const res = await fetch('data/codigos.txt');
    const text = await res.text();
    const codigos = text.split(/\r?\n/).map(c => c.trim()).filter(c => c);

    if (!codigos.includes(codigo)) {
      Swal.fire('Código inválido', 'El código ingresado no existe.', 'error');
      return;
    }

    const numero = parseInt(codigo.match(/\d+/)?.[0] || '0');
    let descuento = 0;
    if (numero >= 0 && numero <= 20) descuento = 5;
    else if (numero <= 40) descuento = 10;
    else if (numero <= 55) descuento = 20;

    state.descuento = descuento;

    if (state.carrito.length === 0) {
      Swal.fire(
        '✅ Código válido',
        `Descuento del ${descuento}% aplicado.<br><br><b>Agregá productos al carrito</b> para usar el descuento.`,
        'success'
      );
      $('#frmCotizador').classList.add('disabled');
    } else {
      $('#frmCotizador').classList.remove('disabled');
      Swal.fire('✅ Código válido', `Descuento del ${descuento}% aplicado.`, 'success');
    }
  } catch {
    Swal.fire('Error', 'No se pudo cargar el archivo de códigos.', 'error');
  }
});

// === COTIZADOR ===
function cotizar(e) {
  e.preventDefault();

  if (state.carrito.length === 0) {
    Swal.fire('Carrito vacío', 'Agregá productos antes de aplicar el descuento.', 'info');
    $('#ctzResultado').innerHTML = `
      <div class="box">
        <p><b>Subtotal:</b> $0,00</p>
        <p><b>IVA (21%):</b> $0,00</p>
        <p><b>Descuento:</b> $0,00</p>
        <p><b>Total con descuento:</b> $0,00</p>
      </div>
    `;
    $('#totalesDescuento').innerHTML = '';
    $('#totalesDescuento').style.display = 'none';
    return;
  }

  const { sub, iva, total } = calcularTotales();
  const descuento = state.descuento || 0;
  const descMonto = total * (descuento / 100);
  const totalConDescuento = total - descMonto;

  $('#ctzResultado').innerHTML = `
    <div class="box">
      <p><b>Subtotal:</b> ${money(sub)}</p>
      <p><b>IVA (21%):</b> ${money(iva)}</p>
      <p><b>Descuento (${descuento}%):</b> -${money(descMonto)}</p>
      <p><b>Total con descuento:</b> ${money(totalConDescuento)}</p>
    </div>
  `;

  Swal.fire({
    title: '✅ Cotización aplicada',
    html: `
      <p>Total original: <b>${money(total)}</b></p>
      <p>Descuento aplicado: <b>${descuento}%</b></p>
      <p><b>Total final: ${money(totalConDescuento)}</b></p>
    `,
    icon: 'success',
    confirmButtonText: 'Aceptar'
  });

  const contDescuento = $('#totalesDescuento');
  contDescuento.innerHTML = `
    <p>Subtotal: <b>${money(sub)}</b></p>
    <p>IVA (21%): <b>${money(iva)}</b></p>
    <p>Descuento (${descuento}%): <b>-${money(descMonto)}</b></p>
    <p><b>Total con descuento:</b> <b>${money(totalConDescuento)}</b></p>
  `;
  contDescuento.style.display = 'block';
}


// ---------- EVENTOS UI ---------- //
function bindUI() {
  $('#btnBuscar').addEventListener('click', () => {
    state.filtros.q = $('#q').value.trim().toLowerCase();
    state.filtros.cat = $('#cat').value;
    renderProductos();
  });
  $('#fInStock').addEventListener('change', (e) => { state.filtros.inStock = e.target.checked; renderProductos(); });
  $('#fPromo').addEventListener('change', (e) => { state.filtros.promo = e.target.checked; renderProductos(); });
  $('#btnCarrito').addEventListener('click', abrirCarrito);
  $('#cerrarCarrito').addEventListener('click', cerrarCarrito);
  $('#btnVaciar').addEventListener('click', (e) => { e.preventDefault(); vaciarCarrito(); });
  $('#btnComprar').addEventListener('click', (e) => { e.preventDefault(); finalizarCompra(); });
  $('#frmCotizador').addEventListener('submit', cotizar);
}

// ---------- INIT ---------- //
(async function init() {
  bindUI();
  await cargarProductos();

  // ✅ Precarga código promocional por defecto si está vacío
  const inputCodigo = document.querySelector('#codigoDescuento');
  if (inputCodigo && !localStorage.getItem('codigoDefaultSet')) {
    inputCodigo.value = 'POLIPROPILEN03';
    localStorage.setItem('codigoDefaultSet', 'true');
  }
})();
